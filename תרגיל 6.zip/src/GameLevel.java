import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Maor Bokobza.
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Counter blocksRemaining;
    private Counter ballsRemaining;
    private Counter score;
    private Counter lives;
    private AnimationRunner runner;
    private boolean running;
    private KeyboardSensor keyboard;
    private LevelInformation levelInformation;
    /**
     * constructor.
     * @param levelInformation an object from LevelInformation, which consists
     *                         the information about every level.
     */
    public GameLevel(LevelInformation levelInformation) {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        blocksRemaining = new Counter();
        ballsRemaining = new Counter();
        score = new Counter();
        lives = new Counter();
        running = false;
        this.levelInformation = levelInformation;
    }

    /**
     *
     * @return blocksRemaining number of remaining blocks.
     */
    public Counter getBlocksRemaining() {
        return blocksRemaining;
    }

    /**
     *
     * @return ballsRemaining number of remining balls.
     */
    public Counter getBallsRemaining() {
        return ballsRemaining;
    }
    /**
     * @param c collidable.
     */
    public void addCollidable(Collidable c) {
        if (c != null) {
            environment.addCollidable(c);
        }
    }

    /**
     *
     * @param c collidable.
     */
    public void removeCollidable(Collidable c) {
        environment.removeCollidable(c);
    }
    /**
     * @param s sprite.
     */
    public void addSprite(Sprite s) {
        if (s != null) {
            sprites.addSprite(s);
        }
    }

    /**
     *
     * @param s asdad
     */
    public void removeSprite(Sprite s) {
        sprites.removeSprite(s);
    }

    /**
     *
     * @return !this.running
     */
    public boolean shouldStop() {
        return !this.running;
    }
    /**
     *
     * @return environment environment.
     */
    public GameEnvironment getEnvironment() {
        return environment;
    }
    // Initialize a new game: create the Blocks and Ball (and Paddle)
    // and add them to the game.
    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * and add them to the game.
     */
    public void initialize() {
        this.gui = new GUI("My cool game", 600, 500);
        this.keyboard = gui.getKeyboardSensor();
        this.runner = new AnimationRunner(this.gui);

        Sprite background = levelInformation.getBackground();
        background.addToGame(this);

        Block upperBorder = new Block(new Rectangle(
                new Point(0, 0), 600, 20), Color.GRAY, 0);
        upperBorder.addToGame(this);

        ScoreIndicator scoreIndicator = new ScoreIndicator(score, 295);
        scoreIndicator.addToGame(this);

        LivesIndicator livesIndicator = new LivesIndicator(lives, 213);
        livesIndicator.addToGame(this);

        LevelNameIndicator levelNameIndicator =
                new LevelNameIndicator(levelInformation.levelName());
        levelNameIndicator.addToGame(this);

        Block lowerBorder = new Block(new Rectangle(
                new Point(20, 480), 580, 20), Color.GRAY, 0);
        lowerBorder.addToGame(this);
        lowerBorder.addHitListener(new BallRemover(this, ballsRemaining));

        Block leftBorder = new Block(new Rectangle(
                new Point(0, 20), 20, 480),
                Color.GRAY, 0);
        leftBorder.addToGame(this);

        Block rightBorder = new Block(new Rectangle(
                new Point(580, 20), 20, 460),
                Color.GRAY, 0);
        rightBorder.addToGame(this);

        List<Block> blocks = levelInformation.blocks();
        for (Block block : blocks) {
            block.addHitListener(new BlockRemover(this, blocksRemaining));
            block.addHitListener(new ScoreTrackingListener(score));
            block.addToGame(this);
        }

        this.createBallsOnTopOfPaddle(levelInformation.numberOfBalls(),
                levelInformation.initialBallVelocities());
        this.creatrPaddle(levelInformation.paddleSpeed(),
                levelInformation.paddleWidth());





        int max = 12;
        /* int blockHeight = 25;
        int blockWidth = 40;
        Color color = null;
        for (int row = 0; row < 6; row++) {
            if (row == 0) {
                color = Color.GRAY;
            }
            if (row == 1) {
                color = Color.RED;
            }
            if (row == 2) {
                color = Color.YELLOW;
            }
            if (row == 3) {
                color = Color.BLUE;
            }
            if (row == 4) {
                color = Color.PINK;
            }
            if (row == 5) {
                color = Color.GREEN;
            }
            for (int col = 0; col < max; col++) {
                Point topLeft = new Point(580 - blockWidth * (col + 1),
                        120 + (row + 1) * blockHeight);
                Block block = null;
                if (row == 0) {
                    block = new Block(new Rectangle(topLeft, blockWidth, blockHeight), color, 2);
                } else {
                    block = new Block(new Rectangle(topLeft, blockWidth, blockHeight), color, 1);
                }
                block.addHitListener(new BlockRemover(this, blocksRemaining));
                block.addHitListener(new ScoreTrackingListener(score));
                block.addToGame(this);
            }
            max--;
        } */
    }

    /**
     *
     */
    private void removeAllPaddles() {
        ArrayList<Paddle> toRemove = new ArrayList<>();

        for (Sprite s : sprites.getSpriteList()) {
            if (s instanceof Paddle) {
                Paddle paddle = (Paddle) s;
                toRemove.add(paddle);
            }
        }
        for (Paddle p : toRemove) {
            removeSprite(p);
            removeCollidable(p);
        }
    }
    /**
     *
     * @param d draw surface
     */
    public void doOneFrame(DrawSurface d) {

        if (this.keyboard.isPressed("p")) {
            this.runner.run(new PauseScreen(this.keyboard));
        }
        if (blocksRemaining.getValue() == 0) {
            score.increase(100);
            removeAllPaddles();
            this.running = false;
        }
        if (this.ballsRemaining.getValue() == 0) {
            removeAllPaddles();
            this.running = false;
        }
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();

    }
    /**
     * Run the game -- start the animation loop.
     */
    public void playOneTurn() {
        this.createBallsOnTopOfPaddle(, List<Velocity>);
        this.running = true;
        this.runner.run(new CountdownAnimation(2., 3, sprites));
        this.runner.run(this);
    }

    /**
     *
     * @param numberOfBalls the number of ball/s.
     * @param initialBallVelocities the initial velocity of the ball/s.
     */
    public void createBallsOnTopOfPaddle(int numberOfBalls,
                                         List<Velocity> initialBallVelocities) {
        for (int i = 0; i < numberOfBalls; i++) {
            Ball ball1 = new Ball(new Point(50, 100), 5, Color.BLACK,
                    environment);
            ball1.setVelocity(initialBallVelocities.get(i));
            ball1.addToGame(this);
        }
    }

    /**
     *
     * @param paddleSpeed the paddle's speed.
     * @param paddleWidth the paddle's width.
     */
    public void creatrPaddle(int paddleSpeed, int paddleWidth) {
        Paddle paddle = new Paddle(new Rectangle(new Point(300, 460),
                paddleWidth, 8),
                Color.yellow,
                this.keyboard,
                20,
                580);
        paddle.addToGame(this);
    }

    /**
     *
     */
    public void run() {
        lives.increase(4);
        while (lives.getValue() > 0) {
            playOneTurn();
            lives.decrease(1);
        }
        playOneTurn();
        gui.close();
    }
}

