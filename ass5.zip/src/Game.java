import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.awt.Color;

/**
 * @author Maor Bokobza.
 */
public class Game {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;

    /**
     * constructor.
     */
    public Game() {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
    }

    /**
     * @param c collidable.
     */
    public void addCollidable(Collidable c) {
        if (c != null) {
            environment.addCollidable(c);
        }
    }

    /**
     * @param s sprite.
     */
    public void addSprite(Sprite s) {
        if (s != null) {
            sprites.addSprite(s);
        }
    }
    /**
     *
     * @return environment environment.
     */
    public GameEnvironment getEnvironment() {
        return environment;
    }
    // Initialize a new game: create the Blocks and Ball (and Paddle)
    // and add them to the game.
    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * and add them to the game.
     */
    public void initialize() {
        this.gui = new GUI("My cool game", 600, 500);

        Block background = new Block(new Rectangle(
                new Point(0, 0), 600, 500), Color.BLUE, -1);
        background.addToGame(this);

        Block upperBorder = new Block(new Rectangle(
                new Point(0, 0), 600, 20), Color.GRAY, 0);
        upperBorder.addToGame(this);

        Block lowerBorder = new Block(new Rectangle(
                new Point(20, 480), 580, 20), Color.GRAY, 0);
        lowerBorder.addToGame(this);

        Block leftBorder = new Block(new Rectangle(
                new Point(0, 20), 20, 480),
                Color.GRAY, 0);
        leftBorder.addToGame(this);

        Block rightBorder = new Block(new Rectangle(
                new Point(580, 20), 20, 460),
                Color.GRAY, 0);
        rightBorder.addToGame(this);

        Ball ball1 = new Ball(new Point(50, 100), 5, Color.BLACK,
                environment);
        ball1.setVelocity(3.5, 4.5);
        ball1.addToGame(this);
        Ball ball2 = new Ball(new Point(70, 100), 5, Color.BLACK,
                environment);
        ball2.setVelocity(3.5, 2.5);
        ball2.addToGame(this);
        Paddle paddle = new Paddle(new Rectangle(new Point(300, 460),
                70, 8),
                Color.yellow,
                gui.getKeyboardSensor(),
                20,
                580);
        paddle.addToGame(this);

        int max = 12;
        int blockHeight = 25;
        int blockWidth = 40;
        Color color = null;
        for (int row = 0; row < 6; row++) {
            if (row == 0) {
                color = Color.GRAY;
            }
            if (row == 1) {
                color = Color.RED;
            }
            if (row == 2) {
                color = Color.YELLOW;
            }
            if (row == 3) {
                color = Color.BLUE;
            }
            if (row == 4) {
                color = Color.PINK;
            }
            if (row == 5) {
                color = Color.GREEN;
            }
            for (int col = 0; col < max; col++) {
                Point topLeft = new Point(580 - blockWidth * (col + 1), 120 + (row + 1) * blockHeight);
                Block block = null;
                if (row == 0) {
                    block = new Block(new Rectangle(topLeft, blockWidth, blockHeight), color, 2);
                } else {
                    block = new Block(new Rectangle(topLeft, blockWidth, blockHeight), color, 1);
                }
                block.addToGame(this);
            }
            max--;
        }
    }



   /**
    * Run the game -- start the animation loop.
    */
    public void run() {
        Sleeper sleeper = new Sleeper();
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing

            DrawSurface d = gui.getDrawSurface();

            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}