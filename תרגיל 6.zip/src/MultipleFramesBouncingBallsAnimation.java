import java.awt.Color;
import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * @author Maor Bokobza
 */
public class MultipleFramesBouncingBallsAnimation {
    /**
     * @param size the ball's size
     * @return new Velocity(1, 1) or new Velocity((50 - size + 1) / 4,
     * (50 - size + 1) / 4) the ball's velocity.
     */
    public static Velocity getSpeedFromSize(int size) {
        if (size >= 50) {
            return new Velocity(1, 1);
        }
        return new Velocity((50 - size + 1) / 4, (50 - size + 1) / 4);
    }

    /**
     * @param args arguments
     */
    public static void main(String[] args) {
        GUI gui = new GUI("bouncing balls", 800, 600);
        Sleeper sleeper = new Sleeper();
        Random random = new Random();
        Ball[] balls = new Ball[args.length];
        for (int i = 0; i < balls.length; i++) {
            if (i < balls.length / 2) {
                int x = random.nextInt(450) + 50;
                int y = random.nextInt(450) + 50;

                balls[i] = new Ball(x, y, Integer.parseInt(args[i]),
                        new Color(random.nextInt(255), random.nextInt(255),
                                random.nextInt(255)));
                balls[i].setVelocity(getSpeedFromSize(balls[i].getSize()));

            } else {
                int x = random.nextInt(150) + 450;
                int y = random.nextInt(150) + 450;
                balls[i] = new Ball(x, y, Integer.parseInt(args[i]),
                        new Color(random.nextInt(255), random.nextInt(255),
                                random.nextInt(255)));
                balls[i].setVelocity(getSpeedFromSize(balls[i].getSize()));

            }
        }
        while (true) {
            DrawSurface d = gui.getDrawSurface();

            d.setColor(Color.gray);
            d.fillRectangle(50, 50, 450, 450);
            ;
            d.setColor(Color.yellow);
            d.fillRectangle(450, 450, 150, 150);

            for (int i = 0; i < balls.length; i++) {
                balls[i].moveOneStep();
            }
            for (int i = 0; i < balls.length; i++) {
                balls[i].drawOn(d);
            }

            gui.show(d);
            sleeper.sleepFor(50); // wait for 50 milliseconds.
        }

    }
}
