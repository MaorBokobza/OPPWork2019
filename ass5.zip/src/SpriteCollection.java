import biuoop.DrawSurface;
import java.util.ArrayList;
/**
 * @author Maor Bokobza.
 */
public class SpriteCollection {
    private ArrayList<Sprite> listOfSprites;

    /**
     * * constructor.
     */
    public SpriteCollection() {
        this.listOfSprites = new ArrayList<>();
    }
    /**
     *
     * @param s sprite.
     */
    public void addSprite(Sprite s) {
        listOfSprites.add(s);
    }

    /**
     * call timePassed() on all sprites.
     **/
    public void notifyAllTimePassed() {
        if (listOfSprites.size() > 0) {
            for (Sprite s : listOfSprites) {
                s.timePassed();
            }
        }
    }

    // call drawOn(d) on all sprites.

    /**
     *
     * @param d drawSurface.
     */
    public void drawAllOn(DrawSurface d) {
        if (listOfSprites.size() > 0) {
            for (Sprite s : listOfSprites) {
                s.drawOn(d);
            }
        }
    }
}