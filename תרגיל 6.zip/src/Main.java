/**
 *
 */
public class Main {
    /**
     * @param args arguments.
     */
    public static void main(String[] args) {
        GameLevel gameLevel = new GameLevel();
        gameLevel.initialize();
        gameLevel.run();
    }
}
