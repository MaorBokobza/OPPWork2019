import biuoop.DrawSurface;

/**
 * Author: Maor Bokobza.
 */
public interface DrawOn {
    /**
     *
     * @param surface surface
     */
    void drawOn(DrawSurface surface);
}
