import biuoop.DrawSurface;

import java.awt.Color;

/**
 * @author Maor Bokobza.
 */
public class LevelNameIndicator implements Sprite {
    private String name;

    /**
     *
     *
     */
    public LevelNameIndicator(String name) {
       this.name = name;
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.BLACK);
        d.drawText(550,
                17,
                "Level Name: " + name,
                20);
    }

    /**
     *
     * @param gameLevel 874
     */
    public void addToGame(GameLevel gameLevel) {
        gameLevel.addSprite(this);
    }

    @Override
    public void timePassed() {

    }
}
