import biuoop.DrawSurface;

import java.awt.Color;

/**
 * @author Maor Bokobza.
 */
public class Block implements Collidable, Sprite {
    private Rectangle rec;
    private Color color;
    private Integer hitPoints;

    /**
     *
     * @param rectangle rectangle.
     * @param color color of the rectangle
     * @param hp hit points
     * @return
     */
    public Block(Rectangle rectangle, Color color, int hp) {
        this.rec = rectangle;
        this.color = color;
        this.hitPoints = hp;
    }

    /**
     *
     * @return rec rectangle.
     */
    public Rectangle getCollisionRectangle() {
        return rec;
    }

    // Notify the object that we collided with it at collisionPoint with
    // a given velocity.
    // The return is the new velocity expected after the hit (based on
    // the force the object inflicted on us).

    /**
     *
     * @param collisionPoint the collision point.
     * @param  currentVelocity the current velocity.
     * @return  new Velocity(currentVelocity.getDx(), currentVelocity.getDy()).
     */
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        if (this.hitPoints > 0) {
            this.hitPoints -= 1;
        }
        if (rec.getUpperLeft().getX() >= collisionPoint.getX()
           || rec.getUpperLeft().getX() + rec.getWidth()
                <= collisionPoint.getX()) {
            currentVelocity.setDx(-currentVelocity.getDx());
        }
        if (rec.getUpperLeft().getY() >= collisionPoint.getY()
            || rec.getUpperLeft().getY() + rec.getHeight()
                <= collisionPoint.getY()) {
            currentVelocity.setDy(-currentVelocity.getDy());
        }
        return new Velocity(currentVelocity.getDx(), currentVelocity.getDy());
    }

    /**
     *
     * @param game a game.
     */
    void addToGame(Game game) {
        game.addCollidable(this);
        game.addSprite(this);
    }

    @Override
    public void drawOn(DrawSurface d) {
        // border of rectangle

        d.setColor(Color.BLACK);
        d.drawRectangle((int) rec.getUpperLeft().getX(),
                (int) rec.getUpperLeft().getY(),
                (int) rec.getWidth(),
                (int) rec.getHeight());

        d.setColor(color);
        d.fillRectangle((int) rec.getUpperLeft().getX(),
                        (int) rec.getUpperLeft().getY(),
                        (int) rec.getWidth(),
                        (int) rec.getHeight());
        d.setColor(Color.BLACK);
        if (hitPoints == 0) {
            d.drawText((int) (rec.getUpperLeft().getX() + rec.getWidth() / 2),
                    (int) (rec.getUpperLeft().getY() + rec.getHeight() / 2),
                    "X",
                    20);
        } else if (hitPoints >= 0) {
            d.drawText((int) (rec.getUpperLeft().getX() + rec.getWidth() / 2),
                    (int) (rec.getUpperLeft().getY() + rec.getHeight() / 2),
                    hitPoints.toString(),
                    20);
        }
    }

    @Override
    public void timePassed() {
        return;
    }
}
