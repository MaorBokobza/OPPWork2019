import java.util.ArrayList;
import java.util.List;


/**
 * @author Maor Bokobza.
 */
public class DirectHit implements LevelInformation {
    private static final int NUMBER_OF_BALLS = 1;
    private static final int PADDLE_SPEED = 100;
    private static final int PADDLE_WIDTH = 400;
    private static final String LEVEL_NAME = "Direct Hit";
    private static final int NUMBER_OF_BALLS_TO_REMOVE = 1;


    @Override
    public int numberOfBalls() {
        return NUMBER_OF_BALLS;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> ballsVelocity = new ArrayList<>();
        Velocity velocity = new Velocity(0, 100);
        ballsVelocity.add(velocity);
        return ballsVelocity;
    }

    @Override
    public int paddleSpeed() {
        return PADDLE_SPEED;
    }

    @Override
    public int paddleWidth() {
        return PADDLE_WIDTH;
    }

    @Override
    public String levelName() {
        return LEVEL_NAME;
    }

    @Override
    public Sprite getBackground() {

        return;
    }

    @Override
    public List<Block> blocks() {
        Block b1 = new Block(new Rectangle(new Point()));
        blocks().add(b1);
        return blocks();
    }

    @Override
    public int numberOfBlocksToRemove() {
        return NUMBER_OF_BALLS_TO_REMOVE;
    }
}
