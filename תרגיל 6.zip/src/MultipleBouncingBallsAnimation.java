import java.awt.Color;
import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * @author Maor Bokobza
 */
public class MultipleBouncingBallsAnimation {
    /**
     * @param size the ball's size.
     * @return new Velocity(1, 1) or new Velocity(50 - size + 1,
     * 50 - size + 1)
     * which is the ball's velocity.
     */
    public static Velocity getSpeedFromSize(int size) {
        if (size >= 50) {
            return new Velocity(1, 1);
        }
        return new Velocity(50 - size + 1, 50 - size + 1);
    }

    /**
     * @param args arguments
     */
    public static void main(String[] args) {
        GUI gui = new GUI("bouncing balls", 400, 400);
        Sleeper sleeper = new Sleeper();
        Random random = new Random();
        Ball[] balls = new Ball[args.length];
        for (int i = 0; i < balls.length; i++) {
            balls[i] = new Ball(random.nextInt(
                    400) + 1, random.nextInt(400),
                    Integer.parseInt(args[i]),
                    new Color(
                            random.nextInt(255),
                            random.nextInt(255),
                            random.nextInt(255)));
            balls[i].setVelocity(getSpeedFromSize(balls[i].getSize()));
        }
        while (true) {
            for (int i = 0; i < balls.length; i++) {
                balls[i].moveOneStep();
            }
            DrawSurface d = gui.getDrawSurface();
            for (int i = 0; i < balls.length; i++) {
                balls[i].drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50); // wait for 50 milliseconds.
        }
    }
}
